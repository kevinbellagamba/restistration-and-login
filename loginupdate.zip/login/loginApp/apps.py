from django.apps import AppConfig


class LoginappConfig(AppConfig):
    name = 'loginApp'
